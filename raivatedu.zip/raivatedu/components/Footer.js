import Link from "next/link";
import { Instagram, Linkedin, Youtube } from "lucide-react";

const columns = [
  { title: "Learn", links: [["All courses", "/courses"], ["Web Development", "/courses"], ["Data Science", "/courses"]] },
  { title: "Company", links: [["Our mentors", "/#mentors"], ["Student results", "/#results"], ["FAQ", "/#faq"]] },
  { title: "Support", links: [["Admissions help", "/courses"], ["EMI options", "/#faq"], ["Refund policy", "/#faq"]] },
];

export default function Footer() {
  return (
    <footer className="bg-indigo-900 text-indigo-100">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 md:grid-cols-[2fr_1fr_1fr_1fr]">
        <div>
          <p className="font-display text-2xl font-extrabold text-white">Raivatedu</p>
          <p className="mt-3 max-w-xs">Live courses, personal mentors and honest admissions advice for learners who want a real career move.</p>
          <div className="mt-5 flex gap-3">
            {[[Instagram, "Instagram"], [Linkedin, "LinkedIn"], [Youtube, "YouTube"]].map(([Icon, name]) => (
              <a key={name} href="#" aria-label={`Raivatedu on ${name}`} className="rounded-full bg-indigo-700 p-2 hover:bg-sun-400 hover:text-ink"><Icon aria-hidden className="h-5 w-5" /></a>
            ))}
          </div>
        </div>
        {columns.map((c) => (
          <nav key={c.title} aria-label={c.title}>
            <h2 className="font-display text-base font-bold text-white">{c.title}</h2>
            <ul className="mt-3 space-y-2">
              {c.links.map(([label, href]) => <li key={label}><Link href={href} className="hover:text-sun-300">{label}</Link></li>)}
            </ul>
          </nav>
        ))}
      </div>
      <p className="border-t border-indigo-700 py-5 text-center text-sm">© {new Date().getFullYear()} Raivatedu. All rights reserved.</p>
    </footer>
  );
}
