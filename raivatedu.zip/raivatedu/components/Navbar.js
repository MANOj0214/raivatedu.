"use client";
import Link from "next/link";
import { useState } from "react";
import { Menu, X, Sparkles } from "lucide-react";
import Button from "./Button";

const links = [
  { href: "/courses", label: "Courses" },
  { href: "/#mentors", label: "Mentors" },
  { href: "/#results", label: "Results" },
  { href: "/#faq", label: "FAQ" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-indigo-100 bg-paper/95 backdrop-blur">
      <nav aria-label="Main" className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link href="/" className="flex items-center gap-2 font-display text-2xl font-extrabold text-indigo-700">
          <Sparkles aria-hidden className="h-6 w-6 text-sun-500" /> Raivatedu
        </Link>
        <ul className="hidden items-center gap-8 md:flex">
          {links.map((l) => (
            <li key={l.href}><Link href={l.href} className="font-semibold text-muted hover:text-indigo-700">{l.label}</Link></li>
          ))}
        </ul>
        <Button href="/courses" className="hidden md:inline-flex">Apply for admission</Button>
        <button
          type="button" className="rounded-full p-2 text-indigo-700 hover:bg-indigo-50 md:hidden"
          aria-expanded={open} aria-controls="mobile-menu" aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen(!open)} onKeyDown={(e) => e.key === "Escape" && setOpen(false)}
        >
          {open ? <X aria-hidden /> : <Menu aria-hidden />}
        </button>
      </nav>
      {open && (
        <div id="mobile-menu" className="border-t border-indigo-100 bg-paper px-4 pb-4 md:hidden">
          <ul className="flex flex-col py-2">
            {links.map((l) => (
              <li key={l.href}><Link href={l.href} onClick={() => setOpen(false)} className="block rounded-xl px-2 py-3 font-semibold hover:bg-indigo-50">{l.label}</Link></li>
            ))}
          </ul>
          <Button href="/courses" className="w-full" onClick={() => setOpen(false)}>Apply for admission</Button>
        </div>
      )}
    </header>
  );
}
