"use client";
import { useId, useState } from "react";
import { ChevronDown } from "lucide-react";

export default function Accordion({ items }) {
  const [open, setOpen] = useState(0);
  const id = useId();
  return (
    <div className="divide-y divide-indigo-100 rounded-blob border border-indigo-100 bg-white">
      {items.map((item, i) => {
        const isOpen = open === i;
        return (
          <div key={item.q ?? item.title}>
            <h3>
              <button
                type="button" id={`${id}-b${i}`} aria-expanded={isOpen} aria-controls={`${id}-p${i}`}
                onClick={() => setOpen(isOpen ? -1 : i)}
                className="flex w-full items-center justify-between gap-4 px-6 py-4 text-left text-lg font-bold hover:bg-indigo-50"
              >
                {item.q ?? item.title}
                <ChevronDown aria-hidden className={`h-5 w-5 shrink-0 transition-transform ${isOpen ? "rotate-180" : ""}`} />
              </button>
            </h3>
            <div id={`${id}-p${i}`} role="region" aria-labelledby={`${id}-b${i}`} hidden={!isOpen} className="px-6 pb-5 text-muted">
              {item.a ?? item.body}
            </div>
          </div>
        );
      })}
    </div>
  );
}
