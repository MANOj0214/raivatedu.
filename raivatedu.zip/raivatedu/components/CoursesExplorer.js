"use client";
import { useState } from "react";
import { SearchX } from "lucide-react";
import CourseCard from "./CourseCard";
import Button from "./Button";
import { courses, categories } from "@/lib/data";

const sorters = {
  popular: (a, b) => b.reviews - a.reviews,
  "price-asc": (a, b) => a.price - b.price,
  "price-desc": (a, b) => b.price - a.price,
  rating: (a, b) => b.rating - a.rating,
};

export default function CoursesExplorer({ initialCategory = "All", initialQuery = "" }) {
  const [category, setCategory] = useState(["All", ...categories].includes(initialCategory) ? initialCategory : "All");
  const [sort, setSort] = useState("popular");
  const [query, setQuery] = useState(initialQuery);

  const q = query.trim().toLowerCase();
  const visible = courses
    .filter((c) => (category === "All" || c.category === category) && (!q || `${c.title} ${c.summary}`.toLowerCase().includes(q)))
    .sort(sorters[sort]);

  const reset = () => { setCategory("All"); setQuery(""); };

  return (
    <>
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div role="group" aria-label="Filter by category" className="flex flex-wrap gap-2">
          {["All", ...categories].map((c) => (
            <button key={c} type="button" aria-pressed={category === c} onClick={() => setCategory(c)}
              className={`rounded-full px-4 py-2 font-semibold ring-1 ring-indigo-200 transition-colors ${category === c ? "bg-indigo-600 text-white" : "bg-white hover:bg-indigo-50"}`}>{c}</button>
          ))}
        </div>
        <div className="flex gap-3">
          <div>
            <label htmlFor="search" className="mb-1 block text-sm font-semibold">Search</label>
            <input id="search" type="search" value={query} onChange={(e) => setQuery(e.target.value)} className="w-40 rounded-full border border-indigo-200 bg-white px-4 py-2 sm:w-52" />
          </div>
          <div>
            <label htmlFor="sort" className="mb-1 block text-sm font-semibold">Sort by</label>
            <select id="sort" value={sort} onChange={(e) => setSort(e.target.value)} className="rounded-full border border-indigo-200 bg-white px-4 py-2">
              <option value="popular">Most popular</option>
              <option value="rating">Highest rated</option>
              <option value="price-asc">Price: low to high</option>
              <option value="price-desc">Price: high to low</option>
            </select>
          </div>
        </div>
      </div>
      <p aria-live="polite" className="mt-6 text-muted">{visible.length} {visible.length === 1 ? "course" : "courses"} found</p>
      {visible.length ? (
        <div className="mt-4 grid gap-6 md:grid-cols-2 lg:grid-cols-3">{visible.map((c) => <CourseCard key={c.slug} course={c} />)}</div>
      ) : (
        <div className="mt-6 rounded-blob bg-white p-12 text-center ring-1 ring-indigo-100">
          <SearchX aria-hidden className="mx-auto h-12 w-12 text-indigo-500" />
          <h2 className="mt-4 text-2xl font-bold">No courses match yet</h2>
          <p className="mt-2 text-muted">Try a different category or a shorter search word.</p>
          <Button variant="ghost" className="mt-6" onClick={reset}>Clear filters</Button>
        </div>
      )}
    </>
  );
}
