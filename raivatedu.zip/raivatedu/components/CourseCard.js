import Link from "next/link";
import { Clock, Star, BarChart3 } from "lucide-react";
import { rupees } from "@/lib/data";

export default function CourseCard({ course }) {
  return (
    <article className="flex flex-col rounded-blob border border-indigo-100 bg-white p-6 transition-shadow hover:shadow-lg focus-within:shadow-lg">
      <span className="w-fit rounded-full bg-indigo-50 px-3 py-1 text-sm font-semibold text-indigo-700">{course.category}</span>
      <h3 className="mt-3 text-xl font-bold leading-snug">
        <Link href={`/courses/${course.slug}`} className="hover:text-indigo-700">{course.title}</Link>
      </h3>
      <p className="mt-2 flex-1 text-muted">{course.summary}</p>
      <ul className="mt-4 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted">
        <li className="flex items-center gap-1"><Clock aria-hidden className="h-4 w-4" />{course.weeks} weeks</li>
        <li className="flex items-center gap-1"><BarChart3 aria-hidden className="h-4 w-4" />{course.level}</li>
        <li className="flex items-center gap-1"><Star aria-hidden className="h-4 w-4 fill-sun-400 text-sun-500" />{course.rating} ({course.reviews})</li>
      </ul>
      <p className="mt-4 text-2xl font-extrabold text-indigo-700">{rupees(course.price)}</p>
    </article>
  );
}
