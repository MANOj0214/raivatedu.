import Link from "next/link";

const styles = {
  primary: "bg-sun-400 text-ink hover:bg-sun-500 active:bg-sun-500",
  secondary: "bg-indigo-600 text-white hover:bg-indigo-700 active:bg-indigo-900",
  ghost: "border-2 border-indigo-600 text-indigo-700 hover:bg-indigo-50 active:bg-indigo-100",
};

export default function Button({ href, variant = "primary", className = "", children, ...props }) {
  const base = `inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 font-bold transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${styles[variant]} ${className}`;
  if (href) return <Link href={href} className={base} {...props}>{children}</Link>;
  return <button className={base} {...props}>{children}</button>;
}
