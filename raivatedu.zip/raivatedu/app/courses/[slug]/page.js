import { notFound } from "next/navigation";
import { Clock, BarChart3, Star, CheckCircle2 } from "lucide-react";
import Button from "@/components/Button";
import Accordion from "@/components/Accordion";
import { courses, syllabus, testimonials, rupees } from "@/lib/data";

export const generateStaticParams = () => courses.map((c) => ({ slug: c.slug }));

export function generateMetadata({ params }) {
  const course = courses.find((c) => c.slug === params.slug);
  if (!course) return {};
  return { title: course.title, description: course.summary, openGraph: { title: course.title, description: course.summary } };
}

export default function CourseDetail({ params }) {
  const course = courses.find((c) => c.slug === params.slug);
  if (!course) notFound();

  return (
    <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 lg:grid-cols-[1fr_340px]">
      <div>
        <p className="font-semibold text-indigo-700">{course.category}</p>
        <h1 className="mt-2 text-4xl font-extrabold md:text-5xl">{course.title}</h1>
        <p className="mt-4 text-lg text-muted">{course.summary}</p>
        <ul className="mt-5 flex flex-wrap gap-5 font-semibold">
          <li className="flex items-center gap-1"><Clock aria-hidden className="h-5 w-5" />{course.weeks} weeks</li>
          <li className="flex items-center gap-1"><BarChart3 aria-hidden className="h-5 w-5" />{course.level}</li>
          <li className="flex items-center gap-1"><Star aria-hidden className="h-5 w-5 fill-sun-400 text-sun-500" />{course.rating} from {course.reviews} reviews</li>
        </ul>

        <h2 className="mb-4 mt-12 text-2xl font-extrabold">Syllabus</h2>
        <Accordion items={syllabus} />

        <section aria-labelledby="inst-h" className="mt-12 flex items-center gap-5 rounded-blob bg-indigo-50 p-6">
          <span aria-hidden className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-sun-400 font-display text-2xl font-extrabold">{course.instructor[0]}</span>
          <div>
            <h2 id="inst-h" className="text-xl font-bold">Your instructor: {course.instructor}</h2>
            <p className="text-muted">Practising professional who teaches in small live batches and reviews every learner&apos;s project personally.</p>
          </div>
        </section>

        <h2 className="mb-4 mt-12 text-2xl font-extrabold">Learner reviews</h2>
        <ul className="space-y-4">
          {testimonials.map((t) => (
            <li key={t.name} className="rounded-blob bg-white p-6 ring-1 ring-indigo-100">
              <p>“{t.quote}”</p>
              <p className="mt-2 font-bold">{t.name} <span className="font-normal text-muted">· {t.detail}</span></p>
            </li>
          ))}
        </ul>
      </div>

      <aside aria-label="Enrol in this course" className="lg:sticky lg:top-24 lg:self-start">
        <div className="rounded-blob bg-white p-6 shadow-lg ring-1 ring-indigo-100">
          <p className="text-3xl font-extrabold text-indigo-700">{rupees(course.price)}</p>
          <p className="text-sm text-muted">or from {rupees(Math.round(course.price / 6))}/month with EMI</p>
          <ul className="my-5 space-y-2">
            {["Live classes with recordings", "Weekly 1:1 mentor call", "7-day full refund", "Certificate on completion"].map((f) => (
              <li key={f} className="flex gap-2"><CheckCircle2 aria-hidden className="h-5 w-5 shrink-0 text-indigo-600" />{f}</li>
            ))}
          </ul>
          <Button href="/courses" className="w-full">Enrol now</Button>
          <Button href="/courses" variant="ghost" className="mt-3 w-full">Talk to admissions</Button>
        </div>
      </aside>
    </div>
  );
}
