import CoursesExplorer from "@/components/CoursesExplorer";

export const metadata = {
  title: "Courses",
  description: "Compare Raivatedu courses by category, level, duration and price. Filter and sort to find the right batch.",
  openGraph: { title: "Raivatedu courses", description: "Live courses in tech, design, marketing and English." },
};

export default function CoursesPage({ searchParams }) {
  return (
    <div className="mx-auto max-w-6xl px-4 py-14">
      <h1 className="text-4xl font-extrabold md:text-5xl">Find your course</h1>
      <p className="mb-8 mt-3 max-w-xl text-lg text-muted">Every course includes live classes, mentor check-ins and a final project.</p>
      <CoursesExplorer initialCategory={searchParams?.category} initialQuery={searchParams?.q} />
    </div>
  );
}
