import { Search, Code2, BarChart3, Palette, Megaphone, MessageCircle, GraduationCap } from "lucide-react";
import Button from "@/components/Button";
import CourseCard from "@/components/CourseCard";
import Accordion from "@/components/Accordion";
import { courses, mentors, stats, testimonials, faqs, categories } from "@/lib/data";

export const metadata = {
  title: "Raivatedu | Live courses with personal mentors",
  description: "Join live batches in web development, data science, UI/UX and spoken English. Every learner gets a personal mentor.",
  openGraph: { title: "Raivatedu | Learn with a mentor beside you", description: "Live courses, personal mentors and placement support." },
};

const categoryIcons = [Code2, BarChart3, Palette, Megaphone, MessageCircle, GraduationCap];

export default function Home() {
  return (
    <>
      <section className="relative overflow-hidden bg-indigo-600 text-white">
        <div aria-hidden className="bob absolute -right-10 top-10 h-40 w-40 rounded-[40%_60%_55%_45%] bg-sun-400 md:right-20 md:h-64 md:w-64" />
        <div className="relative mx-auto max-w-6xl px-4 py-20 md:py-28">
          <h1 className="max-w-2xl text-4xl font-extrabold leading-tight md:text-6xl">Learn a skill this semester. Get hired by the next one.</h1>
          <p className="mt-5 max-w-xl text-lg text-indigo-100">Live evening classes, a personal mentor and projects you can show to employers. Start with a course that fits where you are today.</p>
          <form action="/courses" role="search" className="mt-8 flex max-w-xl flex-col gap-3 rounded-[2rem] bg-white p-2 sm:flex-row sm:rounded-full">
            <label htmlFor="q" className="sr-only">Search courses</label>
            <div className="flex flex-1 items-center gap-2 px-4 text-ink">
              <Search aria-hidden className="h-5 w-5 text-muted" />
              <input id="q" name="q" type="search" placeholder="Try “Python” or “UI design”" className="w-full bg-transparent py-3 placeholder:text-muted focus:outline-none" />
            </div>
            <Button type="submit">Find courses</Button>
          </form>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16" aria-labelledby="cat-h">
        <h2 id="cat-h" className="text-3xl font-extrabold">Popular categories</h2>
        <ul className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
          {categories.map((c, i) => {
            const Icon = categoryIcons[i];
            return (
              <li key={c}>
                <a href={`/courses?category=${encodeURIComponent(c)}`} className="flex h-full flex-col items-center gap-3 rounded-blob bg-white p-5 text-center font-bold ring-1 ring-indigo-100 hover:bg-sun-300">
                  <Icon aria-hidden className="h-8 w-8 text-indigo-600" />{c}
                </a>
              </li>
            );
          })}
        </ul>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16" aria-labelledby="feat-h">
        <div className="flex items-end justify-between gap-4">
          <h2 id="feat-h" className="text-3xl font-extrabold">Featured courses</h2>
          <Button href="/courses" variant="ghost">Browse all courses</Button>
        </div>
        <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {courses.slice(0, 3).map((c) => <CourseCard key={c.slug} course={c} />)}
        </div>
      </section>

      <section id="mentors" className="bg-indigo-50 py-16" aria-labelledby="mentor-h">
        <div className="mx-auto max-w-6xl px-4">
          <h2 id="mentor-h" className="text-3xl font-extrabold">Learn from people who do the work</h2>
          <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {mentors.map((m) => (
              <li key={m.name} className="rounded-blob bg-white p-6 text-center">
                <span aria-hidden className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-sun-400 font-display text-3xl font-extrabold">{m.name[0]}</span>
                <h3 className="mt-4 text-lg font-bold">{m.name}</h3>
                <p className="text-sm font-semibold text-indigo-700">{m.role}</p>
                <p className="mt-2 text-sm text-muted">{m.note}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section id="results" className="mx-auto max-w-6xl px-4 py-16" aria-labelledby="res-h">
        <h2 id="res-h" className="text-3xl font-extrabold">What our learners achieve</h2>
        <dl className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="rounded-blob bg-indigo-600 p-6 text-white">
              <dt className="order-2 text-indigo-100">{s.label}</dt>
              <dd className="font-display text-4xl font-extrabold text-sun-400">{s.value}</dd>
            </div>
          ))}
        </dl>
        <ul className="mt-8 grid gap-6 md:grid-cols-3">
          {testimonials.map((t) => (
            <li key={t.name}>
              <figure className="h-full rounded-blob bg-white p-6 ring-1 ring-indigo-100">
                <blockquote className="text-lg">“{t.quote}”</blockquote>
                <figcaption className="mt-4 font-bold">{t.name}<span className="block text-sm font-normal text-muted">{t.detail}</span></figcaption>
              </figure>
            </li>
          ))}
        </ul>
      </section>

      <section id="faq" className="mx-auto max-w-3xl px-4 pb-16" aria-labelledby="faq-h">
        <h2 id="faq-h" className="mb-8 text-3xl font-extrabold">Questions before you enrol</h2>
        <Accordion items={faqs} />
      </section>

      <section className="px-4 pb-16">
        <div className="mx-auto max-w-6xl rounded-blob bg-sun-400 px-6 py-14 text-center">
          <h2 className="text-3xl font-extrabold md:text-4xl">Your next batch starts on the 1st</h2>
          <p className="mx-auto mt-3 max-w-xl">Seats are capped at 30 per batch so every learner gets mentor time. Pick a course and reserve yours.</p>
          <Button href="/courses" variant="secondary" className="mt-6">Reserve my seat</Button>
        </div>
      </section>
    </>
  );
}
